package com.mysite.bigData.service;

import java.util.Optional;

import org.springframework.stereotype.Service;

import com.mysite.bigData.dto.UserDTO;
import com.mysite.bigData.entity.UserEntity;
import com.mysite.bigData.repository.UserRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class UserService {

	private final UserRepository userRepository;
	
	public void save(UserDTO userDTO) {
		//회원가입구현 기능안함
		//1. dto -> entity변환
		//2. repository의 save 메서드 호출
		UserEntity userEntity = UserEntity.toUserEntity(userDTO);
		userRepository.save(userEntity);
		
		
		
		
	}
	
	public UserDTO login(UserDTO userDTO) {
		
		//디비조회
		Optional<UserEntity> byUser = userRepository.findByUser(userDTO.getUser());
		if(byUser.isPresent()) {
			//아이디조회있을경우
			UserEntity userEntity = byUser.get();
			if(userEntity.getPassword().equals(userDTO.getPassword())) {
				//비번일치 할 경우 entity->dto변환후 리턴 
				UserDTO dto = UserDTO.toUserDTO(userEntity);
				return dto;
			}else {
				//비번불일치
				return null;
			}
			
		}else {
			//아이디조회 없을경우
			return null;
		}
		
	}
	
	
}
