package com.mysite.bigData.service;

import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.mysite.bigData.dto.MailDTO;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
// 메일서비스 (google smtp 연동)
public class MailService {
    private JavaMailSender mailSender;
    private static final String FROM_ADDRESS = "eom910427@gmail.com";//메일발송자 메일

    public void mailSend(MailDTO mailDTO) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(mailDTO.getAddress());//메일 받는자 
        message.setFrom(MailService.FROM_ADDRESS);//메일 발송자
        message.setSubject(mailDTO.getTitle());// 제목
        message.setText(mailDTO.getMessage());// 내용

        mailSender.send(message);//메일보내기
    }
}
