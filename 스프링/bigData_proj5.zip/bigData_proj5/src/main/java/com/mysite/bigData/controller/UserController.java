package com.mysite.bigData.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.mysite.bigData.dto.UserDTO;
import com.mysite.bigData.service.UserService;

import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
public class UserController {

	// 생성자 주입
	private final UserService userService;

	@PostMapping("/loginck")
	public String loginck(@ModelAttribute UserDTO userDTO, HttpSession session) {

		UserDTO loginResult = userService.login(userDTO);

		if (loginResult != null) {
			// 로그인 성공
			session.setAttribute("user", loginResult.getUser());
			return "index";
		} else {
			// 로그인 실패
			return "land";
		}

	}

	@GetMapping("/logout")
	public String logout(HttpSession session) {
		session.invalidate();
		return "land";

	}

}