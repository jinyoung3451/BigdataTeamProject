package com.mysite.bigData.entity;

import com.mysite.bigData.dto.UserDTO;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Setter
@Getter
@Table(name="user_table")
public class UserEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)//오토인크리먼트
	private long id;
	
	@Column(unique = true)
	private String user;
	
	@Column
	private String password;
	
	// UserDTO를 UserEntity로 변환
	public static UserEntity toUserEntity(UserDTO userDTO) {
		
		UserEntity userEntity = new UserEntity();
		userEntity.setUser(userDTO.getUser());
		userEntity.setPassword(userDTO.getPassword());
		return userEntity;
		
		
	}
	
}
