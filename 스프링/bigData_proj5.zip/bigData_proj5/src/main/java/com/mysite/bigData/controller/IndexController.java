package com.mysite.bigData.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.mysite.bigData.dto.UserDTO;
import com.mysite.bigData.service.UserService;

import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
@Controller
@RequiredArgsConstructor
public class IndexController {
   
   
  
//   User 로그인 시 입력된 세션값 받아오기 
   private final HttpSession session;
   
   @GetMapping("/")
    public String root() {
       return "land";
    }
   
   @GetMapping  ("/index")
   public String index(@ModelAttribute UserDTO userDTO) {
       String user = (String) session.getAttribute("user");
        
       //세션값이 null 이 아닐경우 접속 가능 else 접속 불가
        if(user!=null) {
           return "index";
        }else {
           return "land";
        }
       
       
    }
    @GetMapping("/dashboard1")
    public String dashboard1() {
       
       String user = (String) session.getAttribute("user");
       System.out.println(user);
       if(user!=null) {
          return "dashboard1";
       }else {
          return "land";
       }
       
       
    }
    @GetMapping("/dashboard2")
    public String dashboard2() {
       String user = (String) session.getAttribute("user");
       if(user!=null) {
          return "dashboard2";
       }else {
          return "land";
       }
    }
    @GetMapping("/dashboard3")
    public String dashboard3() {
       String user = (String) session.getAttribute("user");
       if(user!=null) {
          return "dashboard3";
       }else {
          return "land";
       }
    }
    @GetMapping("/dashboard4")
    public String dashboard4() {
       String user = (String) session.getAttribute("user");
       if(user!=null) {
          return "dashboard4";
       }else {
          return "land";
       }
    }
    @GetMapping("/team")
    public String team() {
       String user = (String) session.getAttribute("user");
       if(user!=null) {
          return "team";
       }else {
          return "land";
       }
    }
    @GetMapping("/dev")
    public String dev() {
       String user = (String) session.getAttribute("user");
       if(user!=null) {
          return "dev";
       }else {
          return "land";
       }
    }
    
    
    
       
}


