package com.mysite.bigData.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mysite.bigData.entity.UserEntity;


// ID 조회 Class
public interface UserRepository extends JpaRepository<UserEntity, Long> {
	
	Optional<UserEntity> findByUser(String user);
	

}
