package com.mysite.bigData.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.mysite.bigData.dto.MailDTO;
import com.mysite.bigData.service.MailService;


import lombok.AllArgsConstructor;

@Controller
@AllArgsConstructor
public class MailController {
    private final MailService mailService;

    
    // 메일 연동 컨트롤러
    @PostMapping("/mail")
    public String execMail(@ModelAttribute MailDTO mailDTO, Model model) {
        mailService.mailSend(mailDTO);
        model.addAttribute("mailOk","메일전송완료");
        model.addAttribute("searchUrl","/team");
        
        
        return "team";
    }
    
   
    
}
