package com.mysite.bigData.dto;


import com.mysite.bigData.entity.UserEntity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class UserDTO {
	
	private long id;
	private String user;
	private String password;
	
	
	// 유저 entity를 userDTO로 변환 (로그인 확인할떄 필요함)
	public static UserDTO toUserDTO(UserEntity userEntity) {
		
		UserDTO userDTO = new UserDTO();
		
		userDTO.setId(userEntity.getId());
		userDTO.setUser(userEntity.getUser());
		userDTO.setPassword(userEntity.getPassword());
		
		return userDTO;
		
		
	}

}
